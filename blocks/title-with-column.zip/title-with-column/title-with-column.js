export default function decorate(block) {
  block.classList.add('title-with-column');
}
